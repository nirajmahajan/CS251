# import here

def fn_plot1d(fn, x_min, x_max, filename):
    # write your code here
    pass

def nth_derivative_plotter(fn, n, x_min, x_max, filename):
    # write your code here
    pass

def fn_plot2d(fn, x_min, x_max, y_min, y_max, filename):
    # write your code here
    pass

def b(x):
    # write your code here
    pass

def g(x):
    # write your code here
    pass

def h(x):
    # write your code here
    pass

def twodsinc(x,y):
    # write your code here
    pass
