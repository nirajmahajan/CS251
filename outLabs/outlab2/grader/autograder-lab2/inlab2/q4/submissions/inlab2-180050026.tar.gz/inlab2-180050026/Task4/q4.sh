sed -e 's/\([A-Z]\)/\L\1/g
	/^$/d
	/[a-z]/!d
	s/ \|\t\|\./\n/g' $1 | 
	sed -e '/[a-z]/!d' | 
	sed 's/^[^[:alpha:]]\+// 
	     s/[^[:alpha:]]\+$//' | 
	awk '!seen[$0]++' |
	awk '{print $1 | "sort -k 1"}'
		  
		 
		 




#REFERENCE : taken from https://stackoverflow.com/questions/44758527/how-to-remove-punctuation-from-end-and-start-of-a-word-with-sed-in-linux   the punctuation marks remover

#https://stackoverflow.com/questions/1444406/how-can-i-delete-duplicate-lines-in-a-file-in-unix the duplicate remover 
 

