#!/bin/bash
awk '{if (NR == 1) {print $0 "\tPoints"}}' $1
awk '{if (NR != 1) {print $0 "\t" (($3 * 4) + ($4 * 2))}}' $1
