# Your code goes here. 
# Temporarily it has a command which replace all occurences of a in a file to a. and all occurences of b to b. you need to overwrite the same

# to lower case 
sed -e 's/\(.\)/\L\1/g' $1 > a"$$".txt
# new line 
sed -i -e 's/[ ] */\n/g' a"$$".txt
# remove empty line
sed -i -e '/^$/d' a"$$".txt
# remove lines with only punctuation
sed -i -e '/^[^a-zA-Z]*$/d' a"$$".txt
# remove lines starting with arbit punctuation
sed -i -e 's/^[^a-zA-Z]*\([a-zA-Z][a-zA-Z]*\)/\1/g' a"$$".txt
# remove lines ending with arbit punctuation
sed -i -e 's/\([a-zA-Z][a-zA-Z]*\)[^a-zA-Z]*$/\1/g' a"$$".txt
# remove repetetions
awk '{for (i=1;i<=NF;i++) if(a[$1] == 0) { print $1; a[$1]++;}}' a"$$".txt > b"$$".txt
# sort
awk '{a[$1] = 1;} END{asorti(a); for(i=1;i<=length(a);i++){print a[i]}}' b"$$".txt

#cat a.txt
rm a"$$".txt
rm b"$$".txt
