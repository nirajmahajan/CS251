var searchData=
[
  ['update_5frec_13',['update_rec',['../stud__rec_8cpp.html#a5f76d225e6068d2ab4c247ad2a50c0bb',1,'stud_rec.cpp']]]
];
