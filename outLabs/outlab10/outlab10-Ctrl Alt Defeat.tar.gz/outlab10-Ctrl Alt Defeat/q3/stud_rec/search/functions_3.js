var searchData=
[
  ['delete_5frec_21',['delete_rec',['../stud__rec_8cpp.html#ad0d50c71170a324955a3b99e971125a6',1,'stud_rec.cpp']]],
  ['displaymenu_22',['displaymenu',['../stud__rec_8cpp.html#ae916eff90a404bf3f91eacf254ad5f70',1,'stud_rec.cpp']]]
];
