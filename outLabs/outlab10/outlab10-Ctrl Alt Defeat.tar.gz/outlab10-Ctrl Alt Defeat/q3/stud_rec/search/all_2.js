var searchData=
[
  ['clean_3',['clean',['../stud__rec_8cpp.html#a565c6592db5b2286b5d22b63c25d0abb',1,'stud_rec.cpp']]]
];
