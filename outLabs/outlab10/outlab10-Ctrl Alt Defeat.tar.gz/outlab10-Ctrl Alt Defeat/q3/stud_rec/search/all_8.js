var searchData=
[
  ['viewall_14',['viewall',['../stud__rec_8cpp.html#a25009d50098acab8e0e4204ae042ea63',1,'stud_rec.cpp']]]
];
