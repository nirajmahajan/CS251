var searchData=
[
  ['add_5frec_0',['add_rec',['../stud__rec_8cpp.html#a4c6c95b357544b58ff71d2dc1f043bc9',1,'stud_rec.cpp']]],
  ['average_1',['average',['../stud__rec_8cpp.html#aa54aa88a2f8134c04dca729da54c939f',1,'stud_rec.cpp']]]
];
