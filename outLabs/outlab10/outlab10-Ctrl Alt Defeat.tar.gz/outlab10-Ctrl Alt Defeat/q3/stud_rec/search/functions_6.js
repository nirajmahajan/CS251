var searchData=
[
  ['search_25',['search',['../stud__rec_8cpp.html#a22b376d86f15d363c2841a9ed3cd3d78',1,'stud_rec.cpp']]],
  ['showmax_26',['showmax',['../stud__rec_8cpp.html#a976837a3def4973cdf71301ad61f4acf',1,'stud_rec.cpp']]],
  ['showmin_27',['showmin',['../stud__rec_8cpp.html#af7716f01a9e36381c194c40a8c30a149',1,'stud_rec.cpp']]]
];
