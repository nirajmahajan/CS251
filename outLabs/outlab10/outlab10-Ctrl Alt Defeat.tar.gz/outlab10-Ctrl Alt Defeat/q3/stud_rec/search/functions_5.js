var searchData=
[
  ['main_24',['main',['../stud__rec_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'stud_rec.cpp']]]
];
