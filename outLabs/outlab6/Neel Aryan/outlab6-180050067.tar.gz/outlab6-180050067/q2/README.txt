Use the tictactoe.html for the normal marks.
The script for this is script.js.

For the BONUS task bonus.html is to be used.
The script for bonus is bonus-script.js. 

The reset button is treated as a tie if you press it in-game.
If you press it during countdown, it will be as if 
clicked inside the grid i.e. the countdown will stop and next game will start.
 
The players' turns alternate as asked.